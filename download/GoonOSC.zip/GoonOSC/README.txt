Here is the source code and Linux build.

This is version 1.0, pretty buggy but im tired and probably won't work on this for a while so I pushed the release

check github for updates: https://github.com/Chooger/Goon-OSC/
